from src.crewco_api.api import API

def api():
    api = API()
    return api
